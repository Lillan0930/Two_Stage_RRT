"""
SRP Residual Fusion: Shared Region Prototype + Modality-specific Residual
=========================================================================
P = RRT(HE)              ← shared prototype (anchor)
Δ = MLP([LN(P), LN(M)])  ← IHC residual
g = σ(MLP([LN(P), LN(M)])) ← per-patch gate
Z = P + β · g · Δ        ← fused feature
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class SRPScaleFusion(nn.Module):
    """Scale-only fusion: IHC only amplifies/dampens HE tokens, no new directions."""
    def __init__(self, dim=512, beta=0.1):
        super().__init__()
        self.beta = beta
        self.ln_p = nn.LayerNorm(dim)
        self.ln_m = nn.LayerNorm(dim)
        self.scale = nn.Sequential(
            nn.Linear(dim * 2, dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(dim // 4, 1),
            nn.Tanh(),
        )

    def forward(self, P, M):
        x = torch.cat([self.ln_p(P), self.ln_m(M)], dim=-1)
        s = self.scale(x)                     # [B,N,1] ∈ [-1,1]
        Z = P * (1.0 + self.beta * s)         # scale modulation only
        return Z, s, None


class SRPResidualFusion(nn.Module):
    def __init__(self, dim=512, beta=0.1):
        super().__init__()
        self.beta = beta
        self.ln_p = nn.LayerNorm(dim)
        self.ln_m = nn.LayerNorm(dim)

        self.residual = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.ReLU(inplace=True),
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )

        self.gate = nn.Sequential(
            nn.Linear(dim * 2, dim // 4),
            nn.ReLU(inplace=True),
            nn.Linear(dim // 4, 1),
            nn.Sigmoid(),
        )

    def forward(self, P, M):
        x = torch.cat([self.ln_p(P), self.ln_m(M)], dim=-1)
        delta = self.residual(x)
        gate = self.gate(x)
        Z = P + self.beta * gate * delta
        return Z, gate, delta
