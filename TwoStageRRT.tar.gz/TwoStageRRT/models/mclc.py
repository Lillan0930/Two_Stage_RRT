"""
MCLC: Manifold-Constrained Logit Correction
============================================
Sinkhorn-normalized mixing matrix W. HE is anchor, PR can only contribute
through a doubly-stochastic weighted sum.
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


def sinkhorn(log_alpha, n_iters=5, eps=1e-6):
    W = torch.exp(log_alpha)
    for _ in range(n_iters):
        W = W / (W.sum(dim=-1, keepdim=True) + eps)
        W = W / (W.sum(dim=-2, keepdim=True) + eps)
    return W


class ManifoldLogitCorrection(nn.Module):
    def __init__(self, num_modalities=2, num_classes=2, init_diag=2.0, frozen=False):
        super().__init__()
        init = torch.zeros(num_modalities, num_modalities)
        for i in range(num_modalities):
            init[i, i] = init_diag
        if frozen:
            self.register_buffer('log_alpha', init)
        else:
            self.log_alpha = nn.Parameter(init)
        self.frozen = frozen

    def forward(self, logits_list):
        Z = torch.stack(logits_list, dim=1)       # [B, M, C]
        W = sinkhorn(self.log_alpha, n_iters=5)    # [M, M]
        Z_mixed = torch.einsum("ij,bjc->bic", W, Z)  # [B, M, C]
        logits_final = Z_mixed[:, 0, :]             # HE stream only
        return logits_final, W
