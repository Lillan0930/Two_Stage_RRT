"""
Clean Anchor Fusion — 改进版多模态融合（保留 Cross-Attention）
==============================================================
基于特征质量分析：
  - HE 与 IHC 互补（cosine ~0.6）
  - IHC 之间极度冗余（cosine 0.92-0.99）

设计：
  1. HE Bypass — HE 不参与模态混合
  2. IHC Compression — 冗余 IHC 加权压缩
  3. Cross-Attention — HE(query) attend IHC(key/value)，跨模态交互
  4. Sparse Gate — 每个 region 独立决定是否加 IHC
  5. Residual — HE + gate * cross_attended_IHC

数据流:
  HE ──────────────────────────────────────→ fused = HE + α·gate·IHC_info
  IHCs → Compress → CrossAttn(Q=HE, K=IHC, V=IHC) → Gate → ↗
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class IHCCompressor(nn.Module):
    """
    IHC 模态压缩：每个 IHC 独立 MLP 提取特征 → concat → Linear Projection。

    不提前加权求和（不丢信息），让 projection 自己学：
      - ER 重要 → projection 给它大权重
      - HER2 没用 → projection 自动忽略
      - PR/Ki67 一般 → projection 适度取用

    表达能力远高于 weighted sum。
    """
    def __init__(self, dim, num_ihc):
        super().__init__()
        self.dim = dim
        self.num_ihc = num_ihc

        # 每个 IHC 模态独立提取特征
        self.modality_mlps = nn.ModuleList([
            nn.Sequential(
                nn.Linear(dim, dim),
                nn.LayerNorm(dim),
                nn.ReLU(inplace=True),
            ) for _ in range(num_ihc)
        ])

        # concat 后投影回 dim
        self.concat_proj = nn.Sequential(
            nn.Linear(dim * num_ihc, dim),
            nn.LayerNorm(dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, ihc_tokens):
        """
        Args:
            ihc_tokens: [B, R, num_ihc, D]
        Returns:
            compressed: [B, R, D]
        """
        B, R, N, D = ihc_tokens.shape

        # 每个 IHC 模态过自己的 MLP
        processed = []
        for i in range(N):
            x = self.modality_mlps[i](ihc_tokens[:, :, i, :])  # [B, R, D]
            processed.append(x)

        # concat → [B, R, N*D] → projection → [B, R, D]
        concat = torch.cat(processed, dim=-1)
        return self.concat_proj(concat)


class CrossModalityAttention(nn.Module):
    """
    跨模态 Cross-Attention: HE (query) attend IHC (key/value)

    Q = HE:  "我这个 region 需要什么 IHC 信息？"
    K = IHC: "我这些 region 有哪些 IHC 信息？"
    V = IHC: "取这些 IHC 信息"

    每个 HE region 可以关注任意 IHC region 的信息。
    """
    def __init__(self, dim, num_heads=4, dropout=0.1):
        super().__init__()
        self.cross_attn = nn.MultiheadAttention(
            embed_dim=dim, num_heads=num_heads,
            batch_first=True, dropout=dropout
        )
        self.norm = nn.LayerNorm(dim)

    def forward(self, he, ihc):
        """
        Args:
            he:  [B, R, D] — HE region tokens (query)
            ihc: [B, R, D] — IHC compressed (key/value)
        Returns:
            attended: [B, R, D] — HE-aware IHC information
        """
        attended, attn_weights = self.cross_attn(
            query=he,    # [B, R, D]
            key=ihc,     # [B, R, D]
            value=ihc,   # [B, R, D]
        )
        return self.norm(attended), attn_weights


class SparseGate(nn.Module):
    """
    稀疏门控 — 每个 region 独立决定是否加入 IHC 信号。
    init_bias 为负 → gate 初始接近 0 → 默认不加 IHC。
    """
    def __init__(self, dim, init_bias=-1.0):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(dim * 2, dim // 4),  # concat[HE, IHC_attended]
            nn.ReLU(inplace=True),
            nn.Linear(dim // 4, 1),
        )
        nn.init.constant_(self.gate[-1].bias, init_bias)

    def forward(self, he, ihc_attended):
        """
        Args:
            he: [B, R, D]
            ihc_attended: [B, R, D]
        Returns:
            gate: [B, R, 1]
        """
        concat = torch.cat([he, ihc_attended], dim=-1)  # [B, R, 2D]
        return torch.sigmoid(self.gate(concat))


class CleanAnchorFusion(nn.Module):
    """
    Clean Anchor Fusion:
      HE ──────────────────────────────→ HE_out
      IHCs → Compress → CrossAttn → Gate → +residual → fused

    支持 2-5 模态，anchor_idx 默认 0 (HE)。
    """
    def __init__(self, dim, num_modalities, num_heads=4,
                 anchor_idx=0, gate_temperature=1.0, **kwargs):
        super().__init__()
        self.dim = dim
        self.num_modalities = num_modalities
        self.anchor_idx = anchor_idx
        self.num_ihc = num_modalities - 1

        # 多 IHC 时压缩去冗余
        self.ihc_compressor = IHCCompressor(dim, self.num_ihc) if self.num_ihc >= 2 else None

        # 跨模态 Cross-Attention: HE query → IHC key/value
        self.cross_attn = CrossModalityAttention(dim, num_heads=num_heads)

        # 稀疏门控 — gate_temperature 映射为 init_bias: 越高 temperature → gate 越开放
        gate_init_bias = -gate_temperature
        self.sparse_gate = SparseGate(dim, init_bias=gate_init_bias)

        # 输出 projection
        self.output_proj = nn.Sequential(
            nn.Linear(dim, dim),
            nn.LayerNorm(dim),
        )

        # HE+IHC 融合 MLP — gate 开启时用，替代简单的加法
        self.fusion_mlp = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.LayerNorm(dim),
            nn.ReLU(inplace=True),
            nn.Linear(dim, dim),
        )

    def forward(self, region_tokens):
        """
        fused = (1-gate) * HE + gate * mix(HE, IHC)
        gate=0 → 纯 HE（保底不倒退）
        gate=1 → HE+IHC 融合
        """
        B, R, N, D = region_tokens.shape

        # 分离 HE 和 IHC
        he = region_tokens[:, :, self.anchor_idx, :]  # [B, R, D]

        ihc_list = []
        for i in range(N):
            if i != self.anchor_idx:
                ihc_list.append(region_tokens[:, :, i, :])
        ihc = torch.stack(ihc_list, dim=2)  # [B, R, num_ihc, D]

        # Step 1: 压缩冗余 IHC
        if self.ihc_compressor is not None:
            ihc_compact = self.ihc_compressor(ihc)  # [B, R, D]
        else:
            ihc_compact = ihc.squeeze(2)  # [B, R, D]

        # Step 2: 跨模态 Cross-Attention — HE query IHC
        ihc_attended, _ = self.cross_attn(he, ihc_compact)  # [B, R, D]

        # Step 3: Gate — 每个 region 学习用多少 IHC
        gate = self.sparse_gate(he, ihc_attended)  # [B, R, 1]

        # Step 4: 插值融合 — gate=0 纯 HE, gate=1 纯融合
        concat = torch.cat([he, ihc_attended], dim=-1)  # [B, R, 2D]
        fused_he_ihc = self.fusion_mlp(concat)           # [B, R, D]
        fused = (1 - gate) * he + gate * fused_he_ihc

        # 输出 projection
        fused = self.output_proj(fused)

        return fused
