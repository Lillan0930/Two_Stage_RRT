"""
Partial Semantic Alignment: PR shared → HE shared, PR private retained
=======================================================================
L_align = 1 - cos(P_s, H_s.detach())     ← shared subspace alignment
L_orth  = (P_s_n * P_p_n)^2.mean()       ← shared ⊥ private
L_reg   = ||Δ||²                         ← small residual
L_total = CE + μ·L_align + η·L_orth + ρ·L_reg
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class PartialAlignmentFusion(nn.Module):
    def __init__(self, dim=512, shared_dim=256, mu=0.02, eta=0.01, rho=0.001, lmda=0.02):
        super().__init__()
        self.mu = mu
        self.eta = eta
        self.rho = rho
        self.lmda = lmda

        # PR adapter
        self.pr_adapter = nn.Sequential(nn.Linear(dim, dim), nn.LayerNorm(dim))

        # Shared projection (same weights for HE and PR)
        self.shared_proj = nn.Linear(dim, shared_dim)

        # Private projection
        self.private_proj = nn.Linear(dim, dim - shared_dim)

        # Low-rank residual: dim → 64 → dim
        self.residual = nn.Sequential(
            nn.Linear(dim, 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, dim),
            nn.LayerNorm(dim),
        )

    def forward(self, H, P):
        # PR: adapter
        P = self.pr_adapter(P)

        # Shared subspace (same projection weights)
        P_s = self.shared_proj(P)              # [B,N,S]
        H_s = self.shared_proj(H.detach())      # [B,N,S]

        # Private subspace
        P_p = self.private_proj(P)              # [B,N,D-S]

        # Full PR representation
        P_full = torch.cat([P_s, P_p], dim=-1)  # [B,N,D]

        # Low-rank residual
        delta = self.residual(P_full)           # [B,N,D]

        # Fused
        H_fused = H + self.lmda * delta

        return H_fused, P_s, P_p, H_s, delta
